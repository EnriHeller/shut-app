# demo-pb-11

## Prerequisites
To Start this project properly you must have installed Node js on your device with a version not older than 12.X.

If you want to run this project on `development` mode you must have installed the tool `nodemon`on your device.
## Starting project

run `npm start` on a terminal located in project's root directory to start the project.

run `npm run start:dev` on a terminal located in project's root directory to start project on `development` mode.